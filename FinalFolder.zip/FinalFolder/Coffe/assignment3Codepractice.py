#!/usr/bin/env python
# coding: utf-8

# In[5]:


import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages


# In[7]:


df=pd.read_csv("coffee_survey.csv")
df.sample(5)


# In[27]:


#Who, What, Where, How, Why?
where_drink=df.where_drink.str.split(', ',expand=True).stack().reset_index(drop=True)
where_drink=where_drink.value_counts()
ah=where_drink*100/len(df.where_drink)
ah.index

plt.figure(figsize=(20,10))
plt.barh(ah.index,ah.values)
for i ,(location,percentage) in enumerate(zip(ah.index,ah.values)):
    plt.text(percentage+1,i,f"{percentage:3f}%",ha="right" ,va='center')


# In[34]:


# Matrix shows how many people brew both what’s in the column and the row.
brew_methods_= df.brew.str.get_dummies(sep=', ')

# Compute the matrix of people who brew using both methods
brew_combination_matrix = brew_methods_.T.dot(brew_methods_)

# Calculate the percentage matrix
total_respondents = len(df)
brew_combination_matrix_percent = (brew_combination_matrix / total_respondents) * 100
plt.figure(figsize=(10, 8))
sns.heatmap(brew_combination_matrix_percent, annot=True, cmap='Blues', fmt='.2f')
plt.title('Percentage of People Who Brew Both Methods')
#plt.show()


# In[45]:


brew_methods_


# In[36]:


sns.heatmap(brew_combination_matrix_percent)


# In[37]:


# Age Vs Number of cups
drink_data = pd.crosstab(df['age'], df['cups'], normalize='index') * 100

ax = drink_data.plot(kind='barh', stacked=True, figsize=(10, 6), colormap='Accent')
ax.set_title('Age vs Drink Count Per Day')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Age Group')
plt.legend(title='Drink Count Per Day', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()


# In[38]:


drink_data


# In[44]:


# Age Vs Number of cups
drink_data = pd.crosstab(df['age'], df['cups'], normalize='index') * 100

ax = drink_data.plot(kind='barh',stacked=True,figsize=(20,10))
ax.set_title('Age vs Drink Count Per Day')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Age Group')
plt.legend(title='Drink Count Per Day', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()


# In[ ]:




