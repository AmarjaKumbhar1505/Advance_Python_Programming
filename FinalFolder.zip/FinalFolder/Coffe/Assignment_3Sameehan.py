# Assignment - 3 - More coffee please

import pandas as pd
import matplotlib.pyplot as plt 
import seaborn as sns

data = pd.read_csv('E:\Study\M TECH\Sem-3\APP\coffee_survey.csv')

rows, columns = data.shape
print("Number of rows and columns in the dataset, rows : ", rows, "colums :",  columns)

#########################################################################################################
# Age Distribution of Respondents
age_distribution = data['age'].value_counts(normalize=True).sort_index() * 100

plt.figure(figsize=(10, 6))
age_distribution.plot(kind='barh', color='skyblue')
plt.title('Age Distribution of Respondents')
plt.xlabel('Age Group')
plt.ylabel('Percentage')
plt.xticks(rotation=45)
#plt.show()

#########################################################################################################
# Where do people brew coffee?
simplified_where_drink = {
    "At home": "At home",
    "At the office": "At the office",
    "At a cafe": "At a cafe",
    "On the go": "On the go"
}

# Update the data to reflect these categories
def simplify_where_drink(response):
    for key in simplified_where_drink:
        if key in response:
            return simplified_where_drink[key]
    return "Other"

data['simplified_data'] = data['where_drink'].dropna().apply(simplify_where_drink)

where_drink_distribution_percent = data['simplified_data'].value_counts(normalize=True).sort_index() * 100

plt.figure(figsize=(10, 6))
where_drink_distribution_percent.plot(kind='barh', color='lightgreen')
plt.title('Where do People Brew Coffee? (Simplified)')
plt.xlabel('Location')
plt.xlim(0, 100)
plt.ylabel('Percentage')
plt.xticks(rotation=45)
#plt.show()

################################################################################################
# How do people brew coffee?
simplified_brew = {
    "Pour over": "Pour over",
    "Espresso": "Espresso",
    "French press": "Frech press",
    "Mr. Coffee": "Mr. Coffee",
    "Cold brew" : "Cold brew",
    "Pod Machine" : "Pod Machine",
    "Cometeer" : "Cometeer",
    "Instant coffee" : "Instant coffee",
    "Bean-to-Cup" : "Bean-to-Cup"
}

def simplify_brew(response):
    for key in simplified_brew:
        if key in response:
            return simplified_brew[key]
    return "Other"

data['simplified_brew'] = data['brew'].dropna().apply(simplify_brew)
brew_types_percent = data['simplified_brew'].value_counts(normalize=True).sort_values() * 100

plt.figure(figsize=(10, 6))
brew_types_percent.plot(kind='barh', color='orange')
plt.title('Coffee Brewing Methods vs Percent of Respondents')
plt.xlabel('Percentage of Respondents')
plt.xlim(0, 100)
plt.ylabel('Brewing Method')
#plt.show()

################################################################################################
# Matrix shows how many people brew both what’s in the column and the row.
brew_methods_= data['brew'].str.get_dummies(sep=', ')

# Compute the matrix of people who brew using both methods
brew_combination_matrix = brew_methods_.T.dot(brew_methods_)

# Calculate the percentage matrix
total_respondents = len(data)
brew_combination_matrix_percent = (brew_combination_matrix / total_respondents) * 100
plt.figure(figsize=(10, 8))
sns.heatmap(brew_combination_matrix_percent, annot=True, cmap='Blues', fmt='.2f')
plt.title('Percentage of People Who Brew Both Methods')
#plt.show()

###############################################################################################
# Calculate the percentage of respondents for each purchase location
simplified_purchase = {
    "Speciality coffee shop": "Speciality coffee shop",
    "Local cafe": "Local cafe",
    "National chain": "National chain",
    "Drive-thru": "Drive-thru",
    "Deli or supermarket" : "Deli or supermarket"
}

def simplify_purchase(response):
    for key in simplified_purchase:
        if key in response:
            return simplified_purchase[key]
    return "Other"

data['simplified_purchase'] = data['purchase'].dropna().apply(simplify_purchase)
purchase_percentage = data['simplified_purchase'].value_counts(normalize=True).sort_values() * 100

plt.figure(figsize=(10, 6))
purchase_percentage.plot(kind='barh', color='blue')
plt.title('Where Do People Buy Coffee vs Percent of Respondents')
plt.xlabel('Percentage of Respondents')
plt.xlim(0, 100)
plt.ylabel('Purchase Location')
#plt.show()


####################################################################################################
# What do you add to your coffee ? 
work_counts = data['additions'].value_counts().nlargest(5)
total_counts = data['additions'].value_counts().sum()
percentages = (work_counts / total_counts) * 100

# Plot the data
plt.figure(figsize=(10, 6))  # Adjust size as needed
bars = plt.barh(work_counts.index.sort_values(), percentages.sort_values(), color='skyblue')

# Add data labels for percentages
plt.bar_label(bars, fmt='%.0f%%', label_type='center') 
# Customize the plot
plt.xlim(0, 100)  # Set x-axis limit to 100% for percentage
plt.xlabel('Percent of Respondents')
plt.title('Where do you Brew Coffee?')
plt.grid()
plt.tight_layout()
#plt.show()

####################################################################################################
# Type of milk added to your coffee
milk_types = data['dairy'].str.get_dummies(sep=', ')
milk_type_percentage = milk_types.sum().sort_values() / len(data) * 100

plt.figure(figsize=(10, 6))
milk_type_percentage.plot(kind='barh', color='lightblue')
plt.title('Type of Milk Added to Coffee vs Percentage of Respondents')
plt.xlabel('Percentage of Respondents')
plt.xlim(0, 100)
plt.ylabel('Type of Milk')
#plt.show()

####################################################################################################
# Sweeteners added to coffee
sweeterner_types = data['sweetener'].str.get_dummies(sep=', ')
sweetener_type_percentage = sweeterner_types.sum().sort_values() / len(data) * 100
plt.figure(figsize=(10, 6))
sweetener_type_percentage.plot(kind='barh', color='lightblue')
plt.title('Type of sweetener Added to Coffee vs Percentage of Respondents')
plt.xlabel('Percentage of Respondents')
plt.xlim(0, 100)
plt.ylabel('Type of sweetener')
#plt.show()

####################################################################################################
# Why do you drink coffee ?
why = data['why_drink'].str.get_dummies(sep=', ')
sweetener_type_percentage = why.sum().sort_values() / len(data) * 100

plt.figure(figsize=(10, 6))
sweetener_type_percentage.plot(kind='barh', color='lightblue')
plt.title('Reson for drinking Coffee vs Percentage of Respondents')
plt.xlabel('Percentage of Respondents')
plt.xlim(0, 100)
plt.ylabel('Reason to drink coffee')
#plt.show()

####################################################################################################
# Who doesn't drink coffee because of taste

taste_counts = data['taste'].value_counts(normalize=True) * 100
doesnt_taste_good_percentage = taste_counts.get("No", 0)

plt.figure(figsize=(10, 4))
plt.barh(["Doesn't Taste Good"], [doesnt_taste_good_percentage], color='skyblue')
plt.xlim(0, 100)
plt.title('Percentage of Respondents Who Say Coffee "Doesn\'t Taste Good"')
plt.xlabel('Percentage of Respondents')
plt.ylabel('Response')
#plt.show()

####################################################################################################
# Matrix for 'why do you drink coffee ?'
why_drink = data['why_drink'].str.get_dummies(sep=', ')

# Calculate the co-occurrence matrix (number of respondents who selected each combination of reasons)
cooccurrence = why_drink.T.dot(why_drink)

# Plot the heatmap
plt.figure(figsize=(10, 8))
sns.heatmap(cooccurrence, annot=True, cmap='Oranges', fmt='d')
plt.title('Why People Drink Coffee ????')
plt.xlabel('Reason')
plt.ylabel('Reason')
#plt.show()

####################################################################################################
# Roast preferences against Coffee A B C D
import numpy as np
crosstab = pd.crosstab(data['roast_level'], data['prefer_overall'])
print(crosstab)
crosstab_percent = crosstab.div(crosstab.sum(axis=1), axis=0) * 100
print(crosstab_percent)

tested_prefs = crosstab_percent.columns
roast_prefs = crosstab_percent.index
n_prefs = len(tested_prefs)
n_roasts = len(roast_prefs)

# Define bar properties
bar_height = 0.8  # Total height allocated to all bars in a group

individual_bar_height = bar_height / n_prefs
fig, ax = plt.subplots(figsize=(12, 8))
y_positions = np.arange(n_roasts)
colors = sns.color_palette("Set2", n_prefs)

# Plot each tested coffee preference
for i, (pref, color) in enumerate(zip(tested_prefs, colors)):
    # Calculate the position offset for each bar in the group
    offset = (i - n_prefs / 2) * individual_bar_height + individual_bar_height / 2
    ax.barh(
        y_positions + offset, 
        crosstab_percent[pref], 
        height=individual_bar_height * 0.9,  # Slightly smaller to add spacing
        label=pref,
        color=color
    )

# Set y-ticks to be in the center of each group
ax.set_yticks(y_positions)
ax.set_yticklabels(roast_prefs)
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Roast Preference')
ax.set_title('Roast Preferences vs Tested Coffee Preferences')

ax.set_xlim(0, 100)

ax.legend(title='Tested Coffee Preference', bbox_to_anchor=(1.05, 1), loc='upper left')

plt.tight_layout()
#plt.show()

###################################################################################################
# Age Vs Number of cups
drink_data = pd.crosstab(data['age'], data['cups'], normalize='index') * 100

ax = drink_data.plot(kind='barh', stacked=True, figsize=(10, 6), colormap='Accent')
ax.set_title('Age vs Drink Count Per Day')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Age Group')
plt.legend(title='Drink Count Per Day', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()

###################################################################################################
# Political Affiliation Vs Roast Preferences
roast_data = pd.crosstab(data['political_affiliation'], data['prefer_overall'], normalize='index') * 100

ax = roast_data.plot(kind='barh', stacked=True, figsize=(10, 6), colormap='Set1')
ax.set_title('Political Affiliation vs Roast Preference')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Political Affiliation')
plt.legend(title='Roast Preference', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()

###################################################################################################
# Political Affiliation Vs Age

preference = pd.crosstab(data['political_affiliation'], data['age'], normalize='index') * 100

ax = preference.plot(kind='barh', stacked=True, figsize=(10, 6), colormap='Set2')
ax.set_title('Political Affiliation vs Age')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Political Affiliation')
plt.legend(title='Political Affiliation Vs Age', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()

###################################################################################################
# Roast preferences Vs Age
roast_data = pd.crosstab(data['age'], data['roast_level'], normalize='index') * 100

ax = roast_data.plot(kind='barh', stacked=True, figsize=(10, 8), colormap='Dark2')

ax.set_title('Roast Preferences vs Age')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Age Group')
plt.legend(title='Roast Preference', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()

##################################################################################################
# Roast preferences Vs Gender
roast_by_gender = pd.crosstab(data['gender'], data['roast_level'], normalize='index') * 100

ax = roast_by_gender.plot(kind='barh', stacked=True, figsize=(10, 8), colormap='tab20')
ax.set_title('Roast Preferences vs Gender')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Gender')
plt.legend(title='Roast Preference', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()

##################################################################################################
# Preferenes in Roast Vs Number of kids
kids = pd.crosstab(data['number_children'], data['roast_level'], normalize='index') * 100

ax = kids.plot(kind='barh', stacked=True, figsize=(10, 8), colormap='tab10')
ax.set_title('Roast Preferences vs Number of kids')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Number of kids')
plt.legend(title='Roast Preference', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()

##################################################################################################
# Roast references Vs Ethinicity
ethnicity = pd.crosstab(data['ethnicity_race'], data['roast_level'], normalize='index') * 100

ax = ethnicity.plot(kind='barh', stacked=True, figsize=(10, 8), colormap='tab20')
ax.set_title('Roast Preferences vs Number of kids')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Number of kids')
plt.legend(title='Roast Preference', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()

##################################################################################################
# Roast preferences Vs Money spent on coffee
money_spent = pd.crosstab(data['total_spend'], data['roast_level'], normalize='index') * 100

ax = money_spent.plot(kind='barh', stacked=True, figsize=(10, 8), colormap='tab10')
ax.set_title('Roast preferences Vs Money spent on coffee')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Money spent on coffee in Dollars')
plt.legend(title='Roast Preference', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()

##################################################################################################
# Roast preferences Vs Highest price paid for a cup.
most_paid = pd.crosstab(data['most_paid'], data['roast_level'], normalize='index') * 100

ax = most_paid.plot(kind='barh', stacked=True, figsize=(10, 8), colormap='tab20')
ax.set_title('Roast preferences Vs Highest price paid for a cup')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('Highest price paid for a cup')
plt.legend(title='Roast Preference', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
#plt.show()

##################################################################################################
# Roast preferences Vs. Amount you'd most willing to pay for a cup.
most_willing = pd.crosstab(data['most_willing'], data['roast_level'], normalize='index') * 100

ax = most_willing.plot(kind='barh', stacked=True, figsize=(10, 8), colormap='tab10')
ax.set_title('Roast preferences Vs. Amount you would most willing to pay for a cup.')
ax.set_xlabel('Percentage of Respondents')
ax.set_ylabel('most willing to pay for a cup')
plt.legend(title='Roast Preference', bbox_to_anchor=(1.05, 1), loc='upper left')
plt.tight_layout()
plt.show()
