import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Load the data into a Pandas dataframe

#Basic Data Inspection 
#a. Load the dataset and display the first 10 rows.
print("\nLoad the dataset and display the first 10 rows\n")
df = pd.read_csv('coffee_survey.csv')
print(df.head(10))

#b. How many rows and columns are present in the dataset?
print(f"\nNumber of rows are {df.shape[0]} and Number of columns are {df.shape[1]} ")

#c. What are the data types of each column?

print("\n\ndata types of each column ")
df.info()




#Handling Missing Data 
#a. Identify the columns with missing data and their respective counts.


#a. Identify the columns with missing data and their respective counts.
missing_data = df.isnull().sum()
print("\n\n\nIdentified the columns with missing data and their respective counts")
print(missing_data[missing_data > 0])

#b. For columns with more than 20% missing values, suggest a method to handle them and implement it.
print("\n\n")
print("For columns with more than 20% missing values, suggested a method to handle them is to drop column ")
print("\n\n")
# calculate the threshold for 20% missing values
threshold = 0.2 * len(df)

# iterate over the columns
for column in df.columns:
    # calculate the count of missing values for the column
    missing_count = df[column].isnull().sum()
    
    # check if the column has more than 20% missing values
    if missing_count > threshold:
        # drop the column
        df.drop(column, axis=1, inplace=True)
        
        print(f"Dropped column '{column}' with {missing_count} missing values")
        
        
#Summary Statistics 
#a. Generate summary statistics (mean, median, mode, etc.) for numerical columns (such as expertise, coffee_a_bitterness, and coffee_a_acidity).
print("\n\n Generating summary statistics (mean, median, mode, etc.) for numerical columns (such as expertise, coffee_a_bitterness, and coffee_a_acidity)")
numerical_columns = df.select_dtypes(include=[int, float]).columns

summary_stats = df[numerical_columns].describe()
print(summary_stats)

#b. How does the bitterness preference (coffee_a_bitterness) vary across different age groups? Provide a brief analysis.
print("\n\n\nsummary for how bitterness preference (coffee_a_bitterness) vary across different age groups with a brief analysis.")
age_groups = df.groupby('age')['coffee_a_bitterness'].mean()
print("Age Group and mean value of coffee_a_bitterness")
print(age_groups)

#plot for data analysis
plt.figure(figsize=(10, 6))
plt.plot(age_groups.index, age_groups.values, marker='o')
plt.xlabel('Age')
plt.ylabel('Mean Bitterness Preference')
plt.title('Bitterness Preference by Age Group')
plt.show()


plt.figure(figsize=(10, 6))
plt.bar(age_groups.index, age_groups.values)
plt.xlabel('Age')
plt.ylabel('Mean Bitterness Preference')
plt.title('Bitterness Preference by Age Group')
plt.show()


print("\n Some Observation:")
print("\n 1.The youngest age group (<18 years old) has the highest mean bitterness preference, which may be due to a lack of exposure to bitter flavors or a tendency to prefer stronger flavors.\n\n 2. The 18-24 age group has a relatively low mean bitterness preference, which may be influenced by their coffee consumption habits, such as preferring sweeter or more milky coffee drinks.\n\n 3.The mean bitterness preference increases with age, with a noticeable jump between the 45-54 and 55-64 age groups. This may indicate a shift in taste preferences or a greater appreciation for bitter flavors with age.\n\n\n 4.The >65 age group has a lower mean bitterness preference compared to the 55-64 age group, which may be due to a decline in taste sensitivity or a change in coffee consumption habits with age.\n\n\n Overall, the data suggests that age is a significant factor in bitterness preference, with older adults tend to prefer more bitter coffee. However, there are also variations within age groups, and further analysis may be needed to understand the underlying factors driving these preferences.")
