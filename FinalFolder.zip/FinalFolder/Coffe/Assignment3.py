import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns
from matplotlib.backends.backend_pdf import PdfPages

# Load the data into a Pandas dataframe

#Basic Data Inspection 
#a. Load the dataset and display the first 10 rows.
print("\nLoad the dataset and display the first 10 rows\n")
df = pd.read_csv('coffee_survey.csv')
df.head(5)


with PdfPages('MT2311Amarja_assignment3.pdf') as pdf:
    individual_locations=df.where_drink.str.split(', ', expand=True).stack().reset_index(drop=True)
    location_counts = individual_locations.value_counts()
    location_percentages = (location_counts / len(df.where_drink)) * 100

    # Create a horizontal bar plot
    plt.figure(figsize=(15, 10))
    plt.barh(location_percentages.index, location_percentages.values)
    plt.xlabel('Percentage of Respondants')
    #plt.ylabel('Location')
    plt.title('Where do you brew coffe')
    # Add percentage labels to each bar
    for i, (location, percentage) in enumerate(zip(location_percentages.index, location_percentages.values)):
        plt.text(percentage + 1, i, f'{percentage:.1f}%', ha='right', va='center')

    
    pdf.savefig()
    plt.show()
    plt.close()
    

    Brew_type=df.brew.str.split(', ', expand=True).stack().reset_index(drop=True)
    Brew_counts = Brew_type.value_counts()
    Brew_percentages = (Brew_counts / len(df.brew)) * 100

    # Create a horizontal bar plot
    plt.figure(figsize=(15, 10))
    plt.barh(Brew_percentages.index, Brew_percentages.values)
    plt.xlabel('Percentage of Respondants')

    plt.title('How do you brew coffe')
    # Add percentage labels to each bar
    for i, (location, percentage) in enumerate(zip(Brew_percentages.index, Brew_percentages.values)):
        plt.text(percentage + 1, i, f'{percentage:.1f}%', ha='right', va='center')


    pdf.savefig()
    plt.show()
    plt.close()

    data=df.brew
    data = data[~pd.isna(data)]
    place=Brew_type.unique()
    places_len=len(place)

    cor_matrix=np.zeros((places_len, places_len))
    for i in range(places_len):
        for j in range(places_len):
            loc1=place[i]
            loc2=place[j]
            a=[] 
            for entry in data:
                a_normalized = [item.strip() for item in entry.split(',')]
                #print(a_normalized,loc1,loc2)
                if i==j:
                    c=loc1 in  a_normalized 
                    
                else:
                    c=loc1 in  a_normalized and loc2 in  a_normalized
                #print(c)
                a.append(c)
            #print(sum(a))   
            cor_matrix[i,j]=sum(a)*100/4042
            

    plt.figure(figsize=(15, 10))
    ax = sns.heatmap(cor_matrix, annot=True, cmap='coolwarm', fmt='.1f', square=True, 
                     xticklabels=place, yticklabels=place, cbar_kws={'label': 'Percentage'})
    #sns.heatmap(cor_matrix, annot=True, cmap='coolwarm', square=True, ax=ax)

    plt.title('How Do you Brew coffe?')

    plt.xticks(rotation=90)
    plt.yticks(rotation=0)


    pdf.savefig()
    plt.show()
    plt.close()

    
    #When people buy coffee, most in this survey bought from a specialty shop.
    df.purchase.unique()
    individual_locations=df.purchase.str.split(', ', expand=True).stack().reset_index(drop=True)
    location_counts = individual_locations.value_counts()
    location_percentages = (location_counts / len(df.purchase)) * 100

    # Create a horizontal bar plot
    plt.figure(figsize=(15, 10))
    plt.barh(location_percentages.index, location_percentages.values)
    plt.xlabel('Percentage of Respondants')
    #plt.ylabel('Location')
    plt.title('Where do you buy coffe ?')
    # Add percentage labels to each bar
    for i, (location, percentage) in enumerate(zip(location_percentages.index, location_percentages.values)):
        plt.text(percentage + 1, i, f'{percentage:.1f}%', ha='right', va='center')

    pdf.savefig()
    plt.show()
    plt.close()
    

    #Most people in this group did not add anything to their coffee.
    df.additions.unique()
    individual_locations=df.additions.str.split(', ', expand=True).stack().reset_index(drop=True)
    location_counts = individual_locations.value_counts()
    location_percentages = (location_counts / len(df.additions)) * 100

    # Create a horizontal bar plot
    plt.figure(figsize=(15, 10))
    plt.barh(location_percentages.index, location_percentages.values)
    plt.xlabel('Percentage of Respondants')
    #plt.ylabel('Location')
    plt.title('what do you add to  coffe ?')
    # Add percentage labels to each bar
    for i, (location, percentage) in enumerate(zip(location_percentages.index, location_percentages.values)):
        plt.text(percentage + 1, i, f'{percentage:.1f}%', ha='right', va='center')

    pdf.savefig()
    plt.show()
    plt.close()
    

    
    #For the milk, people added mostly added whole milk, but many used oat milk. Many didn’t add any milk.
    df.dairy.unique()
    individual_locations=df.dairy.str.split(', ', expand=True).stack().reset_index(drop=True)
    location_counts = individual_locations.value_counts()
    location_percentages = (location_counts / len(df.dairy)) * 100

    # Create a horizontal bar plot
    plt.figure(figsize=(15, 10))
    plt.barh(location_percentages.index, location_percentages.values)
    plt.xlabel('Percentage of Respondants')
    #plt.ylabel('Location')
    plt.title('what milk do you add to your coffe ?')
    # Add percentage labels to each bar
    for i, (location, percentage) in enumerate(zip(location_percentages.index, location_percentages.values)):
        plt.text(percentage + 1, i, f'{percentage:.1f}%', ha='right', va='center')

    pdf.savefig()
    plt.show()
    plt.close()
    

    #For sugar, most used regular sugar if any at all.
    df.sweetener.unique()
    individual_locations=df.sweetener.str.split(', ', expand=True).stack().reset_index(drop=True)
    location_counts = individual_locations.value_counts()
    location_percentages = (location_counts / len(df.sweetener)) * 100

    # Create a horizontal bar plot
    plt.figure(figsize=(15, 10))
    plt.barh(location_percentages.index, location_percentages.values)
    plt.xlabel('Percentage of Respondants')
    #plt.ylabel('Location')
    plt.title('what Sugar do you add to your coffe ?')
    # Add percentage labels to each bar
    for i, (location, percentage) in enumerate(zip(location_percentages.index, location_percentages.values)):
        plt.text(percentage + 1, i, f'{percentage:.1f}%', ha='right', va='center')

    pdf.savefig()
    plt.show()
    plt.close()
    

       #Almost everyone drinks coffee because it tastes good, but some have other reasons.
    
    df.why_drink.unique()
    individual_locations=df.why_drink.str.split(', ', expand=True).stack().reset_index(drop=True)
    location_counts = individual_locations.value_counts()
    location_percentages = (location_counts / len(df.why_drink)) * 100

    # Create a horizontal bar plot
    plt.figure(figsize=(15, 10))
    plt.barh(location_percentages.index, location_percentages.values)
    plt.xlabel('Percentage of Respondants')
    #plt.ylabel('Location')
    plt.title('why do you drink coffe ?')
    # Add percentage labels to each bar
    for i, (location, percentage) in enumerate(zip(location_percentages.index, location_percentages.values)):
        plt.text(percentage + 1, i, f'{percentage:.1f}%', ha='right', va='center')

    pdf.savefig()
    plt.show()
    plt.close()


    #Of the people who don’t drink coffee for the taste, I broke down their reasons for drinking coffee. Multiple answers could be selected.

    data2 = df.why_drink[~pd.isna(df.why_drink)]
    place=data2.str.split(', ', expand=True).stack().reset_index(drop=True).unique()
    places_len=len(place)

    cor_matrix=np.zeros((places_len, places_len))
    for i in range(places_len):
        for j in range(places_len):
            loc1=place[i]
            loc2=place[j]
            a=[] 
            for entry in data2:
                a_normalized = [item.strip() for item in entry.split(',')]
                #print(a_normalized,loc1,loc2)
                if i==j:
                    c=loc1 in  a_normalized 
                    
                else:
                    c=loc1 in  a_normalized and loc2 in  a_normalized
                #print(c)
                a.append(c)
            #print(sum(a))   
            cor_matrix[i,j]=sum(a)*100/len(df.why_drink)
            

    plt.figure(figsize=(15, 10))
    ax = sns.heatmap(cor_matrix, annot=True, cmap='Blues', fmt='.1f', square=True, 
                     xticklabels=place, yticklabels=place, cbar_kws={'label': 'Percentage'})
    #sns.heatmap(cor_matrix, annot=True, cmap='coolwarm', square=True, ax=ax)

    plt.title('why Do you drink coffe?')

    plt.xticks(rotation=90)
    plt.yticks(rotation=0)


    pdf.savefig()
    plt.show()
    plt.close()



    # Count occurrences
    counts = df.groupby([df.prefer_abc,df.strength ]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15, 10))

    # Adding labels and title
    ax.set_xlabel('Percentage (%)')
    ax.set_ylabel('Coffee Type')
    ax.set_title('Preference in Roast Vs Tested Coffee Preference')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()



    # Count aGES BY CUPS
    counts = df.groupby([df.age,df.cups]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15,10))

    # Adding labels and title
    ax.set_xlabel('Percentage (%)')
    ax.set_ylabel('Age')
    ax.set_title('Age vs Drink count per day')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()



        # Count occurrences ethnicity_race
    counts = df.groupby([df.ethnicity_race,df.strength]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15, 10))

    # Adding labels and title
    ax.set_xlabel('Percentage (%)')
    ax.set_ylabel('ethnicity_race')
    ax.set_title('ethnicity_race vs Roast Prefernce')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()


    # Count occurrences political_affiliation strength
    counts = df.groupby([df.political_affiliation,df.strength]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15, 10))

    # Adding labels and title
    ax.set_xlabel('Percentage (%)')
    ax.set_ylabel('Political Affiliation')
    ax.set_title('Political Affiliation')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()


    # Count occurrences political_affiliation and age
    counts = df.groupby([df.age,df.political_affiliation]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15, 10))

    # Adding labels and title
    ax.set_xlabel('Percentage by Age Group (%)')
    ax.set_ylabel('Age')
    ax.set_title('Politics by Age ')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()




    # Count occurrences age strength
    counts = df.groupby([df.age,df.strength]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15,10))

    # Adding labels and title
    #ax.set_xlabel('Percentage by Age Group (%)')
    ax.set_ylabel('Age')
    ax.set_title('Roast Preference By Age')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()


    #gender strength
    counts = df.groupby([df.gender,df.strength]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15,10))

    # Adding labels and title
    #ax.set_xlabel('Percentage by Age Group (%)')
    ax.set_ylabel('gender')
    ax.set_title(' Preference in Roast vs gender')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()

    #number_children,strength
    counts = df.groupby([df.number_children,df.strength]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15,10))

    # Adding labels and title
    #ax.set_xlabel('Percentage by Age Group (%)')
    ax.set_ylabel('Number of kids')
    ax.set_title(' Preference in Roast vs Number of kids')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()


    #ethnicity_race strength
    counts = df.groupby([df.ethnicity_race,df.strength]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15,10))

    # Adding labels and title
    #ax.set_xlabel('Percentage by Age Group (%)')
    ax.set_ylabel('ethnicity')
    ax.set_title(' Preference in Roast vs ethnicity')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()




    counts = df.groupby([df.total_spend,df.strength]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    #plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15,10))

    # Adding labels and title
    #ax.set_xlabel('Percentage by Age Group (%)')
    ax.set_ylabel('total_spend')
    ax.set_title(' Preference in Roast vs total_spend Montly')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()


    counts = df.groupby([df.spent_equipment,df.strength]).size().unstack().fillna(0)

    # Calculate percentages
    percentages = counts.div(counts.sum(axis=1), axis=0) * 100
    # Plotting
    ##plt.figure(figsize=(15, 10))
    ax = percentages.plot(kind='barh', stacked=True, figsize=(15,10))

    # Adding labels and title
    #ax.set_xlabel('Percentage by Age Group (%)')
    ax.set_ylabel('total_spend in 5 year')
    ax.set_title(' Preference in Roast vs total_spend last 5 year')
    # Adding percentage labels


    for i, (index, row) in enumerate(percentages.iterrows()):
        total = 0
        for col in percentages.columns:
            percentage = row[col]
            if percentage > 0:
                total += percentage
                ax.text(total - percentage / 2, i, f'{percentage:.1f}%', 
                        va='center', ha='center', color='white', fontsize=10)

    # Show plot
    pdf.savefig()
    plt.show()
    plt.close()
print("All the Plots are saved in MT2311Amarja_assignment3.pdf please check file with this name")



    



    
