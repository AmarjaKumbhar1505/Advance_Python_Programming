import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import seaborn as sns

# Load the data into a Pandas dataframe
df = pd.read_csv('olympics.csv')
df.head()

# Question 1: How many total countries are listed in the table?
print("Question 1: How many total countries are listed in the table?")
print("Total countries:", df['team'].nunique())


# Question 2: How many golds, silver and bronze have India won?
print("\n\n Question 2: How many golds, silver and bronze have India won?")
india_medals = df[df['team'] == 'India']['medal'].value_counts()
print("India's medals:")
print(india_medals)


# Question 3: Plot a boxplot of ages of all athletes. Same for India.

print("\n\n\n Question 3: Plot a boxplot of ages of all athletes. Same for India.")
plt.figure(figsize=(10, 6))

plt.subplot(1, 2, 1)
sns.boxplot(x=df['age'])
plt.title('All Athletes')

plt.subplot(1, 2, 2)
sns.boxplot(x=df[df['team'] == 'India']['age'])
plt.title('India Athletes')
plt.show()


# Question 4: What is the median and mean ages of the male and female athletes
print(" \n\n\n Question 4: What is the median and mean ages of the male and female athletes")
male_ages = df[df['sex'] == 'M']['age']
female_ages = df[df['sex'] == 'F']['age']

print("Male athletes:")
print("Median age:", male_ages.median())
print("Mean age:", male_ages.mean())

print("Female athletes:")
print("Median age:", female_ages.median())
print("Mean age:", female_ages.mean())



# Question 5: Plot the ratio of male:female athletes for each Olympic
print("\n\n\n Question 5: Plot the ratio of male:female athletes for each Olympic")
olympics = df['sport'].unique()
male_female_ratio = []
SPORT_female_countNOTZero=[]
SPORT_female_countIsZero=[]
male_Count_female_zero=[]
print("\nRatio of male:female athletes for each Olympic")
print ("\n Olympic\t\t\t|\t\t male_count\t|\t\t female_count")
print ("--------------------------------------------------------------------------------------------------------")
for olympic in olympics:
    male_count = len(df[(df['sport'] == olympic) & (df['sex'] == 'M')])
    female_count = len(df[(df['sport'] == olympic) & (df['sex'] == 'F')])
    space=(25-len(olympic))
    print(olympic,space*" ","\t|\t\t",male_count,"\t\t|\t\t",female_count)
    if female_count>0:
        ratio = male_count / female_count
        male_female_ratio.append(ratio)
        SPORT_female_countNOTZero.append(olympic)
    else:
        male_Count_female_zero.append(male_count)
        SPORT_female_countIsZero.append(olympic)
print ("--------------------------------------------------------------------------------------------------------")        
print(f"\n\n\n Observation: there are {len(SPORT_female_countIsZero)} olympic sports where female candidate count is Zero. \n So to avoide zero devision Error we are not considering there ratios.\n Instead we plotted these Olympics separate where Female count is zero. \n and Separate plot Ratio when female count is non zero")        
plt.figure(figsize=(10, 6))

#plt.subplot(6, 2, 1)
plt.plot(SPORT_female_countNOTZero, male_female_ratio)
plt.xlabel('sport')
plt.ylabel('Male:Female Ratio')
plt.title('Male:Female Athlete Ratio for Each Olympic')
plt.show()
#plt.subplot(6, 2, 2)
plt.figure(figsize=(10, 6))
plt.plot(SPORT_female_countIsZero, male_Count_female_zero)

plt.xlabel('sport')
plt.ylabel('Male Counts when female count is zero')
plt.title('Male:Female Athlete Ratio for Each Olympic when  when female count is zero')
plt.show()
